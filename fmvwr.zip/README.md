# fmvwr

A React web application to view data about the game "Yu-Gi-Oh Forbidden Memories" (Konami, 1999).

## Current Features

- Search, select, and view card images and statistics.
- Calculate your duel rank given actions performed throughout a duel.

## Planned features

- Fusion search
- Better card display with type and attribute images
- View enemy card drops and calculate drop percentages
