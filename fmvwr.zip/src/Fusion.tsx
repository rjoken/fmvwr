interface Fusion {
  card1: number;
  card2: number;
  result: number;
}

export default Fusion;
