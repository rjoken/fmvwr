enum GuardianStar {
  None = 0,
  Mars = 1,
  Jupiter = 2,
  Saturn = 3,
  Uranus = 4,
  Neptune = 5,
  Pluto = 6,
  Mercury = 7,
  Sun = 8,
  Moon = 9,
  Venus = 10,
}

export default GuardianStar;
