function Title() {
  return (
    <center>
      <h1>FMViewer</h1>
    </center>
  );
}

export default Title;
