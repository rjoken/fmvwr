enum CardAttribute {
  Light = 0,
  Dark = 1,
  Earth = 2,
  Water = 3,
  Fire = 4,
  Wind = 5,
  Magic = 6,
  Trap = 7,
}

export default CardAttribute;
