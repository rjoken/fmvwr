interface Ritual {
  ritualCard: number;
  card1: number;
  card2: number;
  card3: number;
  result: number;
}

export default Ritual;
